## And yeah, it requires the password, Password : ebrajdon
Phonebook is a simple project built in C where you can save the Infos of a person and can modify and delete it too.

## Some Snaps
### 01. Password Page
![Front](/snaps/front.JPG)

### 02. Main Page
![Main](/snaps/main.JPG)
